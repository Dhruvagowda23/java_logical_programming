// Write a program to print your Name, Father's Name and Mailing Address in different lines

class Exercise1 {



} 