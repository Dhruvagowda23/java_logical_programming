// Write a program to print your name

public class Sample1 {

	public static void main(String args[]) {

	//Print your name in Console
	
	}
}