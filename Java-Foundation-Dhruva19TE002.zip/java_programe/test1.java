import java.util.scanner;
class test1
  {
    public Staic void main(String[]args){
      String s1="dhruva";
      String s2="DHruva";
         System.out.println(s1.equals(s2));
      System.out.println(s1.equalsIgnoreCase(s2));
    }
  }