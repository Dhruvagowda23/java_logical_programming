// sample programe
/*
    sample
  java
      programe
      */

import java.lang.system;
  import java.lang.string;

// or import java.lang.*;

class first{
  public static void main(string args[]) {
    system.out.print("welcome the first programe");
  }
}