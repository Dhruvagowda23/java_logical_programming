#######################################
#   Configuration for Run Button      #
#######################################

 

# Provide the name of the directory (assignment or project name)
cd JFM1T2_Exercise1-Dhruvagowda23

 

# Java compile command. Do not change this. 
javac Exercise1.java

 

#This is the main class you want to run. 
#This needs to change every time you want to run a #Java File. 
java  Exercise1

 

#######################################
#   Configuration for GitHub          #
#######################################
# This is a ONE TIME SETUP ONLY
# Configure these variables
EMAIL="ndhruva123@gmail.com"
NAME="Dhruva"
GITHUB_USERNAME="Dhruvagowda23"
GITHUB_ACCESS_TOKEN="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"
 

#######################################
#   DO NOT CHANGE ANYTHING BELOW      #
#######################################

 

#git configuration below make using IDE easy.
git config --global --replace-all user.email $EMAIL
#enter your name
git config --global --replace-all user.name $NAME

 

#create ~/.netrc file
# This .netrc file is used to store your username and your Perosnal Access Token
FILE1=~/.netrc
if test -f "$FILE1"; then
    rm $FILE1
fi

 

echo machine github.com login $GITHUB_USERNAME password $GITHUB_ACCESS_TOKEN  > $FILE1

 

 